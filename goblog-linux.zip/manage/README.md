# 博客后台管理前端文件目录

后台管理前端使用layuiAdmin 来实现，相关文档，可以查阅 [layui.com](http://www.layui.com/admin/)。